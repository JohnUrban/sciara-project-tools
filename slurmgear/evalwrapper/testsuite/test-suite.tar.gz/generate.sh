#!/bin/bash


## clear old files if present
bash reset.sh


##################################
### ASSEMBLIES ###################
##################################

echo "...Generating Assemblies"

## go into asm folder - references
cd asms/refs/

## generate needed files

echo "...Generating Assemblies: snpd"
cd snpdecoligenome/
bash snpthegenome.sh
cd ../

echo "...Generating Assemblies: snpd and mutated"
cd mutatedecoligenome/
bash modifygenome.sh
cd ../

echo "...Generating Assemblies: snpd, mutated, and fragmented"
cd fragmentedmutatedecoligenome
bash fragmentgenome.sh
cd ../

echo "...Generating Assemblies: snpd, mutated, fragmented, and mutated more"
cd mutatefragmentedgenomemore
bash modifygenome.sh
cd ../

echo "...Generating Assemblies: most fragmented and mutated"
cd mostfragmentedmutatedecoligenome/
bash fragmentgenome.sh
cd ../

## leave asm folder - references
cd ../../



##################################
### DATA #########################
##################################

echo "...Generating Data"

## enter data folder
cd data/

cd sim_ilmn_pe
echo "...Generating Data: illumina"
bash makereads.sh
cd ../

cd sim_ont
echo "...Generating Data: ont"
bash makereads.sh
cd long2pe
echo "...Generating Data: ont long2pe"
bash pairedFromLong.sh
cd ../../

cd sim_pb
echo "...Generating Data: pb"
bash makereads.sh
cd long2pe
echo "...Generating Data: pb long2pe"
bash pairedFromLong.sh
cd ../../

cd sim_pbont
echo "...Generating Data: pbont"
bash get.sh
cd ../

cd ecoliknownseqs
echo "...Generating Data: knownseqs"
bash getknowseqs.sh 
cd ../

cd sim_rna_seq
echo "...Generating Data: rnaseq"
bash makereads.sh
cd ../


## leave data folder
cd ../




##################################
### DE NOVO ASMS #################
##################################

## go into denovo
SBATCH=`command -v sbatch`
if [ ! -z $SBATCH ]; then
  echo "...Starting De Novo Assemblies"
  #enter denovo
  cd asms/denovo
  #process abruijn
  cd abruijn
  echo "...Starting De Novo Assemblies: abruijn"
  bash submit-abruijn.sh
  cd ../
  # process canu
  cd canu
  echo "...Starting De Novo Assemblies: canu"
  bash submit-canu.sh 
  cd ../
  #process dbg2olc
  cd dbg2olc
  echo "...Starting De Novo Assemblies: dbg2olc"
  bash fragmentgenome.sh
  bash submit-dbg2olc.sh
  cd ../
  # process falcon
  cd falcon
  echo "...Starting De Novo Assemblies: falcon"
  bash submit-falcon.sh
  cd ../
  #process miniasm
  cd miniasm
  echo "...Starting De Novo Assemblies: miniasm"
  bash submit-miniasm.sh
  cd ../  
  #leave asms/denovo - back to base
  cd ../../
fi



##################################
### DATA - BNG ###################
##################################
## Takes a long time -- so I let the denovo asms start before hand

cd data/sim_bng
echo "...Generating Data: bng"
bash makereads.sh
cd ../../




	
##################################
### EVALS ########################
##################################

mkdir evals
cp util/run-evalwrapper.sh evals/
cp data/sim_rna_seq/reads.fofn evals/rnaseqreads.fofn

while read relpath; do
 readlink -f $relpath 
done < util/relative-input.fofn > evals/input.fofn

while read relpath; do
 readlink -f $relpath 
done < util/relative-input.extended.fofn > evals/input.extended.fofn


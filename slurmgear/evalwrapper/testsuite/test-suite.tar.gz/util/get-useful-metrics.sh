#!/bin/bash


if [ $# -eq 0 ] || [ $1 == "-h" ] || [ $1 == "-help" ] || [ $1 == "--help" ]; then
    echo "
    Usage: bash $0 FOFN OPTION GENOME_SIZE

    ...where FOFN has list of all assemblies used in the assembly evaluations in subdirs you are trying to summarize.
    (( typically called input.fofn ))

    Alt Usage: bash $0 FOFN debug|debugsimple|debugvizmat
    ...writing the word 'debug' as the second argument will create files that count the number of metrics from each function in 2-col tab-delim file.

    Alt Usage: bash $0 FOFN simple
    ...writing the word 'simple' as the second argument will create longtable files that have been pruned compared to both default and vizmat.
    ...like vizmat these are strictly numeric.
    ...only metrics that can easily be interpreted in isolation as better or worse when compared to another assembly were retained
    ...this one can be used for LaTeX table conversion BUT it is not recommended as a part of MANUAL INSPECTION
    ...the default or vizmat provide information that you can process as a human more readily by combining with other info to judge as better or worse or curious
    ...the point of simple is to be able to compare 2 asms and plot -1 or 1 (later on) for better or worse.
    ...use 'simplenames' to get names; use 'simplefactors' to get the multiplication vector to use against each pair of metric scores before ranking (in R)

    Alt Usage: bash $0 FOFN all
    ...writing the word 'all' as the second argument will create the default longtables, the vizmat longtables, and the debug files in one pass.

    Alt Usage: bash $0 FOFN names|vizmatnames|simplenames|simplefactors
    ...writing the word 'names' or 'vizmatnames' or 'simplenames' as the second argument will give a comma-sep list of metric names in the order that they appear in the corresponding long table form.
    ...writing the word 'simplefactors' returns a vector of 1 and -1 to be used to multiply against a vector of scores for the given metric (same order as simple) before ranking in R
    ...for now you still need a dummy word in position 1 -- e.g. 'input.fofn' -- but it will not use it.
    "
    exit
fi

##FOFN=input.fofn
FOFN=$1
NARG=$#
DEBUG=''
DEBUG=$2
G=$3
if [ -z $G ]; then G=292000000; fi

## ASSUMES FOLLOWING DIRS
SHORT=shortread
BIONANO=bionano
LONG=longread
BLAST=blast_analyses
TRANSCRIPTOME=${BLAST}/transcriptome
KNOWN=${BLAST}/knownseqs
DMEL=${BLAST}/dmel
DMELPEP=${BLAST}/dmel_peptides
MOSQ=${BLAST}/anopheles
MOSQPEP=${BLAST}/anopheles_peptides
RNA=rnaseq

##NAME VARIABLES
SIMPLENAMES="Num_Contigs,Max_Contig_Size,NG50,LG50,E_G,Complete_BUSCOs,Bowtie2_Ilmn_Pct,Bowtie2_Pct_Aligned_Concordantly,Bowtie2_Pct_Aligned_Disconcordantly,ALE_Score,ALE_Place_Avg,ALE_Insert_Avg,ALE_kmer_Avg,ALE_Depth_Score_Avg,LAP,REAPR_MBS,REAPR_Pct_EF,REAPR_FCD_Errors_within_a_contig,REAPR_FCD_Errors_over_a_gap,REAPR_Low_frag_cov_within_a_contig,REAPR_Low_frag_cov_over_a_gap,REAPR_Low_Score_Regions,REAPR_Links,REAPR_Soft_Clip,REAPR_Collapsed_repeats,REAPR_Low_Read_Coverage,REAPR_Low_Perfect_Coverage,REAPR_Wrong_Orientation,REAPR_Broken_Num_Contigs,REAPR_Broken_Max_Contig_Length,REAPR_Broken_NG50,REAPR_Broken_LG50,REAPR_Broken_EG,REAPR_Broken_Num_Gaps,REAPR_Broken_Total_Gap_Len,FRC_Num_Features,FRC_Norm_Num_Features_(per_Mb),FRC_Proper,FRC_Wrong_Dist,FRC_Wrong_Orientation,FRC_Wrong_Contig,FRC_Singleton,FRC_Mean_Cov,FRC_Spanning_Cov,FRC_Proper_Pairs_Cov,FRC_Wrong_Mate_Cov,FRC_Singleton_Mate_Cov,FRC_Different_Contig_Cov,BNG_Score,BNG_Span,BNG_Cov,BNG_Num,BNG_1e4*Score/Cov,BNG_Score/Num,BNG_Span/AsmSize,BNG_Cov/AsmSize,BNG_Cov/Span,BNG_Cov/Num,ONT_sum_mapq,ONT_pct_aln,ONT_ratio,ONT_avg_mapq,PacBio_sum_mapq,PacBio_Pct_aln,PacBio_ratio,PacBio_avg_mapq,Sniffles_ONT_Num_SV,Sniffles_PacBio_Num_SV,Sniffles_ONT_Sum_SV,Sniffles_PacBio_Sum_SV"
SIMPLEFACTORS="1,-1,-1,1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,1,1,1,1,1,1,1,1,1,-1,-1,1,-1,1,1,1,1,-1,1,1,1,1,-1,-1,-1,1,1,1,1,-1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,1,1,1,1,1,1"



function getsizestats { ##takes fasta
    ## 6 outputs: ncontigs, asmlen, maxlen, ng50, lg50, eg
    b=`basename $1 .fasta`
    F=sizestats/${b}.tsv
    if [ ! -d sizestats ]; then mkdir sizestats; fi
    if [ ! -f $F ]; then faSize -detailed $1 | asm-stats.py -t -G $G | awk '{gsub(/,/,"\n"); print}' > $F ; fi
    awk 'NR==1 || NR==2 || NR==3 || NR==10 || NR==11 || NR==12 {print $1}' $F
}



function getsizestats_vizmat { ##takes fasta
    ## 5 outputs: ncontigs, maxlen, ng50, lg50, eg
    b=`basename $1 .fasta`
    F=sizestats/${b}.tsv
    if [ ! -d sizestats ]; then mkdir sizestats; fi
    if [ ! -f $F ]; then faSize -detailed $1 | asm-stats.py -t | awk '{gsub(/,/,"\n"); print}' > $F ; fi
    ## asmsize taken out b/c not meaningful in terms of an asm getting better or worse (Except in terms of going further away from expected size)
    awk 'NR==1 || NR==3 || NR==10 || NR==11 || NR==12 {print $1}' $F
}

function getbusco_simple {
    ## 1 output: complete
    ##F=$SHORT/${1}/busco/*/short*
    F=$1
    ## Removed
    ## "Complete and single-copy BUSCOs" "Complete and duplicated BUSCOs" "Fragmented BUSCOs" "Missing BUSCOs"
    ## Since it is unclear w/o specific knowledge that having more or less of the complete buscos as single copy vs duplicated is "better" for an asm
    ## and since missing buscos gives no extra info over complete
    for l in "Complete BUSCOs"; do
        grep "${l}" $F | awk '{print $1}'
    done
}

function getbowtie2_simple {
    ## 3 outputs: overall aln rate, %of all pairs conc, % of all pairs disc
    ##F=$SHORT/${1}/mreads/*.err
    F=$1
    grep "overall alignment rate" $F | awk '{sub(/%/,""); print $1}'
    pair=`grep "were paired; of these:" $F | awk '{print $1}'`
    conc1=`grep "aligned concordantly exactly 1 time" $F | awk '{print $2}' | awk '{sub(/%/,""); sub(/\(/,""); sub(/\)/,""); print}'`
    concmult=`grep "aligned concordantly >1 times" $F | awk '{print $2}' | awk '{sub(/%/,""); sub(/\(/,""); sub(/\)/,""); print}'`
    ## it is not immediately clear if more or less single vs multi is better -- easier to interpret %concordant marginalized over both
    echo $conc1 $concmult | awk '{print $1+$2}'   ## pct aligned concordantly
    ## removed pct DNAC since that does not give any new info wrt pct conc
    ## remove "pct of reads aln conc 0 times that aln disc" since this is not immediately interp as better/worse
    disc1=`grep "aligned discordantly 1 time" $F | awk '{print $1}'`
    pctdisc1=`echo $disc1 $pair | awk '{print 100.0*$1/$2}'`
    echo ${pctdisc1} #pct of total pairs that aln disc
    ## pct unmap does not nec give any more info 
    ## SE read are not immediately comparable/interpretable -- I will let ALE/LAP/REAPR/FRC deal with them
}



function getale_simple {
    F=$1
    #F=$SHORT/${1}/ale/*ALE.txt
    ## 1=ALE score, 2=ncont, 3=asmlen, 4=placeAvg, 5=insertAvg, 6=kmerAvg, 7=depthScoreAvg, 8=depthAvg, 9=totalreads, 10=totalMappedReads, 11=totalUnMappedReads, 12=total placed reads, 13=readlenAvg, 14=avgReadOvlap
    ## trimmed off mapped, unmapped, and placed -- will let those be reflected in BT2 fxn and as part of the other scores here.
    awk 'NR==1 || NR==4 || NR==5 || NR==6 || NR==7 {print $3}' $F
}

function getale_simple_long {
    F=$1
    #F=$SHORT/${1}/ale/*ALE.txt
    ## 1=ALE score, 2=ncont, 3=asmlen, 4=placeAvg, 5=insertAvg, 6=kmerAvg, 7=depthScoreAvg, 8=depthAvg, 9=totalreads, 10=totalMappedReads, 11=totalUnMappedReads, 12=total placed reads, 13=readlenAvg, 14=avgReadOvlap
    ## trimmed off mapped, unmapped, and placed -- will let those be reflected in BT2 fxn and as part of the other scores here.
    awk 'NR==1 || NR==4 || NR==6 || NR==7 {print $3}' $F
}

function getlap {
    #F=$SHORT/${1}/lap/*.lapscore
    F=$1
    awk '{print $1}' $F | head -n 1
}


function getasmstats {
    ## WARN: assumes getsizestats was already run
    F=sizestats/${b}.tsv
    paste -sd"\t" $F
}

function getreapr_simple {
    ## FOR REAPR SIMPLE -- rm sumError and sumWarn -- just use indiv err and warns
    ##D=$SHORT/${1}/reapr/output_directory/
    D=$1
    head -n 1 $D/per-base-mean-score.txt
    ## pctEF, FCD, FCD_gap, frag_cov, frag_cov_gap, lowscore, link, softclip, collapsed repeat, readcov, low perfect cov, readorientation
    ##awk 'NR==2 {OFS="\t"; print 100*$38/$2, $39, $40, $41, $42, $43, $44, $45, $46, $47, $48, $49}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'
    ## get rid of FCD/cov over gap metrics
    ## pctEF, FCD, frag_cov, lowscore, link, softclip, collapsed repeat, readcov, low perfect cov, readorientation
    awk 'NR==2 {OFS="\t"; print 100*$38/$2, $39, $41, $43, $44, $45, $46, $47, $48, $49}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'
    
    ## Broken Asm -size stats -- removed for now b/c it really only seems to matter when aggressive breaking is used since most long-read contigs do not have Ns...
    ## br nseqs,  br longest, 
    #awk 'NR==2 {OFS="\t"; print $21, $23}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'    
    #stats=`getasmstats $1`
    #bstats=`awk '{gsub(/,/,"\t"); print }' ${D}/broken_assembly.sizestats.csv`
    #echo $bstats | awk '{print $10}' ##broken ng50
    #echo $bstats | awk '{print $11}' ##broken lg50
    #echo $bstats | awk '{print $12}' ## broken eg

    ## Below is only useful when not aggressively breaking the assembly as it basically tells you how much it would break it up.
    ## After it is aggressively broken though, these are usually zeroed out -- and therefore not useful to rank. All in all, either use (i) broken asm size stats OR (ii) reapr's gap stats
    ## ngaps, gaplen
    awk 'NR==2 {OFS="\t"; print $36, $37}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'    

    # PAST OUTPUT = #1=mbs, 2=pctEF, 3=FCD, 4=frag_cov, 5=lowscore, 6=link, 7=softclip, 8=collapsed repeat, 9=readcov, 10=low perfect cov, 11=readorientation, 12=br nseqs,  13=broken longest, 14=broken ng50, 15=broken lg50, 16=broken eg, 17=ngaps, 18=gaplen
    # NEW OUTPUT = #1=mbs, 2=pctEF, 3=FCD, 4=frag_cov, 5=lowscore, 6=link, 7=softclip, 8=collapsed repeat, 9=readcov, 10=low perfect cov, 11=readorientation, 12=ngaps, 13=gaplen
}

function getreapr_simple_longread {
    D=$1
    head -n 1 $D/per-base-mean-score.txt
    ## From next awk command: removed $48 -> formerly output #10 --> low perfect cov --> b/c perfect mapping not used for long2pe
    awk 'NR==2 {OFS="\t"; print 100*$38/$2, $39, $41, $43, $44, $45, $46, $47, $49}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'
    awk 'NR==2 {OFS="\t"; print $36, $37}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'    
    # OUTPUT = #1=mbs, 2=pctEF, 3=FCD, 4=frag_cov, 5=lowscore, 6=link, 7=softclip, 8=collapsed repeat, 9=readcov, 10=readorientation, 11=ngaps, 12=gaplen
}

function getreapr_simple_longread_lowcov {
    D=$1
    head -n 1 $D/per-base-mean-score.txt
    ## As with PB version -- From next awk command: removed $48 -> formerly output #10 --> low perfect cov --> b/c perfect mapping not used for long2pe
    ## In addition, From next awk command: removed $41 --> formerly output #4 --> frag_cov (frag cov too low) --> b/c ONT coverage too low for default minimum of 1 where there were too many false positives in ecoli analysis -- ONT min frag cov was set to 0 here to ignore this...
    awk 'NR==2 {OFS="\t"; print 100*$38/$2, $39, $43, $44, $45, $46, $47, $49}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'
    awk 'NR==2 {OFS="\t"; print $36, $37}' ${D}/05.summary.report.tsv | awk '{gsub(/\t/,"\n"); print}'    
    # OUTPUT = #1=mbs, 2=pctEF, 3=FCD, 4=lowscore, 5=link, 6=softclip, 7=collapsed repeat, 8=readcov, 9=readorientation, 10=ngaps, 11=gaplen
}



function getfrc_simple {
    ## WARN: assumes getasmstats was already run
    ## 6=MAPPED
    ## numfrc, normnumfrc, 8=PROPER,9=WRONG_DIST, 11=WRONG_ORIENTATION,12=WRONG_CONTIG,13=SINGLETON, 14=MEAN_COVERAGE,15=SPANNING_COVERAGE,16=PROPER_PAIRS_COVERAGE,17=WRONG_MATE_COVERAGE,18=SINGLETON_MATE_COV,19=DIFFERENT_CONTIG_COV
    ## For now, it doesnt give the raw counts of reads that mapped in a proper pair, w/ wrong dit, w/ wrong orientation, ...etc
    ##   instead it gives all those normalized to number of mapped reads.
    ## The problem with using raw counts is best illustrated with an example:
    ##  If a bad asm has very few reads mapping and they all map with wrong dist or wrong orientn, those counts will still be lower than a good asm with tons more reads mapping and a lower pct mapping wrong...
    ##  When normalized it becomes obvious how to interp 100% wrong mapped vs 10%
    ##  Another example is an assembly with
    F1=$1
    F2=$2
    numfrc=`grep -c -v ^# $F1`
    asmlen=`getasmstats | awk '{print $2}'`
    normfrc=`echo $numfrc $asmlen | awk '{print 1e6*$1/$2}'`
    echo $numfrc
    echo $normfrc
    ## pct of mapped that are proper, pct of mapped that have wrong dist, pct of mapped that have wrong ori, pct of mapped that have wrong contig, pct of mapped as singleton....
    tail -n 1 $F2 | awk 'OFS="\t" {gsub(/,/,"\t"); print 100.0*$8/$6, 100.0*$9/$6, 100.0*$11/$6, 100.0*$12/$6, 100.0*$13/$6}' | awk '{gsub(/\t/,"\n"); print}'
}


function calcmalignerstats {
    #Takes $D for merge directory as $1
    if [ ! -f $1/score.txt ]; then tail -n +2 $1/all.bionano.smoothed.maps.aln | awk '{s+=$19}END{print s}' > $1/score.txt; fi
    if [ ! -f $1/span.txt ]; then awk '{s+=($3-$2)}END{print s}' $1/all.bionano.smoothed.maps.aln.bedGraph > $1/span.txt; fi
    if [ ! -f $1/total_base_cov.txt ]; then awk '{s+=($3-$2)*$4}END{print s}' $1/all.bionano.smoothed.maps.aln.bedGraph > $1/total_base_cov.txt; fi
    if [ ! -f $1/num_alignments.txt ]; then tail -n +2 $1/all.bionano.smoothed.maps.aln | wc -l > $1/num_alignments.txt; fi
    G=$1/*.genome
    asmsize=`awk '{s+=$2}END{print s}' $G`

    ## calculate metrics
    score=`cat $1/score.txt`
    span=`cat $1/span.txt`
    cov=`cat $1/total_base_cov.txt`
    num=`cat $1/num_alignments.txt`
    scorecov=`python -c "print 1e4*$score/$cov.0"`
    scorenum=`python -c "print $score/$num.0"`
    asmsize=`awk '{s+=$2}END{print s}' $G`
    spanasm=`python -c "print $span/$asmsize.0"`
    covasm=`python -c "print $cov/$asmsize.0"`
    covspan=`python -c "print $cov/$span.0"`
    covnum=`python -c "print $cov/$num.0"`

    ## populate allstats.txt
    echo -e score"\t"$score > $1/allstats.txt
    echo -e span"\t"$span >> $1/allstats.txt
    echo -e total_cov"\t"$cov >> $1/allstats.txt
    echo -e num_aln"\t"$num >> $1/allstats.txt
    echo -e 1e4xScore/Cov"\t"$scorecov >> $1/allstats.txt
    echo -e Score/Num"\t"$scorenum >> $1/allstats.txt
    echo -e Span/Asm"\t"$spanasm >> $1/allstats.txt
    echo -e Cov/Asm"\t"$covasm >> $1/allstats.txt
    echo -e Cov/Span"\t"$covspan >>$1/allstats.txt
    echo -e Cov/Num"\t"$covnum >> $1/allstats.txt
}

function getmaligner {
    D=${BIONANO}/${1}/merge
    if [ ! -f ${D}/allstats.txt ]; then 
        calcmalignerstats  ${D}; 
    fi
    grep score ${D}/allstats.txt | awk '{print $2}'
    grep span ${D}/allstats.txt | awk '{print $2}'
    grep total_cov ${D}/allstats.txt | awk '{print $2}'
    grep num_aln ${D}/allstats.txt | awk '{print $2}'
    grep "Score/Num" ${D}/allstats.txt | awk '{print $2}'
    grep "Span/Asm" ${D}/allstats.txt | awk '{print $2}'
    grep "Cov/Asm" ${D}/allstats.txt | awk '{print $2}'
    grep "Cov/Span" ${D}/allstats.txt | awk '{print $2}'
    grep "Cov/Num" ${D}/allstats.txt | awk '{print $2}'
    # Formerly: score, span, total_cov, num, 1e4*Score/Cov, avgscore=Score/Num, pctAsmSpanned=Span/Asm, AvgCovPerBaseInAsm=Cov/Asm, AvgCovPerSpannedBase=Cov/Span, AvgMolSize=Cov/NumAln
    # Now: 1e4*Score/Cov was removed b/c it did not seem to be able to rank assemblies well in E.coli testing -- the others did better
    ## score, span, total_cov, num, avgscore=Score/Num, pctAsmSpanned=Span/Asm, AvgCovPerBaseInAsm=Cov/Asm, AvgCovPerSpannedBase=Cov/Span, AvgMolSize=Cov/NumAln
}


function getlongreadstats_simple {
    for VAR in pctalnlen pctmatch_allreads pctmatch_alnreads pctmatch_alns pct_reads_that_aln alnratio pct_multi_ctg avgalnlen_allaln avgalnlen_allalnread avgalnlen_allread avgmapq_per_aln avgmapq_per_read avgmapq_with_unmap avgalnscore_per_aln avgalnscore_aln_reads avgalnscore_allreads; do
      grep -w $VAR ${1} | awk '{print $2}'
    done
}

function getsniffles_simple {
    #D=${LONG}/${1}/stats
    # give path to sniffles_x dir
    D=${1}
    DEL=${D}/numdel
    DUP=${D}/numdup
    INS=${D}/numins
    INV=${D}/numinv
    TRA=${D}/numtra
    NUM=${D}/*numsv
    SUM=${D}/*sumsv
    ORDEREDFILES="${DEL} ${DUP} ${INS} ${INV} ${TRA} ${NUM} ${SUM}"

    for f in ${ORDEREDFILES}; do
      ##bn=`basename $f`
      ##echo -e $bn"\t"`cat $f`
      echo `cat $f`
    done
}




function getpilon {
 PILONDIR=${1}
 G=${2}

 #get asm size
 g=`getasmstats | awk '{print $2}'`

 # pct confirmed - good to see proportion of assembly in good standing, but can penalize assemblies that indeed have more confirmed bases at the expense of a larger asm size that makes pct go down
 awk 'NR==2 {print $3}' ${PILONDIR}/confirmed.txt

 # pct of expected genome size confirmed -- normalizes all to expected genome size to see pct of G confirmed
 awk -v "G=$G" 'NR==2 {print 100.0*$1/G}' ${PILONDIR}/confirmed.txt
 
 # number SNPs found per Mb
 awk 'NR==2 {print $1}' ${PILONDIR}/vars.txt

 # number small INSs found per Mb
 awk 'NR==2 {print $2}' ${PILONDIR}/vars.txt

 # number small DELs found per Mb
 awk 'NR==2 {print $4}' ${PILONDIR}/vars.txt

 # number SNPs+INSs+DELs found per Mb
 awk 'NR==2 {print $1+$2+$4}' ${PILONDIR}/vars.txt

 # total num alt alleles in VCF per Mb
 c=`cat ${PILONDIR}/num_alt_alleles.txt`
 echo 1000000.0*$c/$g | bc -l

 # Pct of asm flagged as Large collapsed region -- Note this can be inflated for assemblies with bubbles kept if Pilon is identifying 10kb+ stretches with >= 2*Global_Mean_cov -- perhaps not if it is local cov on contig....
 c=`grep "^Large collapsed region" ${PILONDIR}/pilon.err | awk '{s+=$6}END{print s}'`
 echo 100.0*$c/$g | bc -l
 
 # Num LCRs per Mb
 c=`grep -c "^Large collapsed region" ${PILONDIR}/pilon.err`
 echo 1000000.0*$c/$g | bc -l


}




function getsimple {
     ##Size - 5 outputs: ncontigs, maxlen, ng50, lg50, eg
#    getsizestats_vizmat $line
     ##short read
#    getbowtie2_simple $SHORT/${b}/mreads/*.err 
#    getale_simple $SHORT/${b}/ale/*ALE.txt 
#    getlap $SHORT/${b}/lap/*.lapscore
#    getreapr_simple $SHORT/${b}/reapr/output_directory/ 
#    getfrc_simple $SHORT/${b}/frc/*gff $SHORT/${b}/frc/*frc_assemblyTable.csv
#    getpilon ${SHORT}/${b}/pilonvars/ 292000000
     #
#    PacBio - aln stats, sniffles, ALE, FRC, REAPR
#    getlongreadstats_simple ${LONG}/${b}/mreads/pacbio*simple.txt
#    getsniffles_simple ${LONG}/${b}/sniffles_pb
#    getale_simple_long $LONG/${b}/ale_pb/*ALE.txt
#    getfrc_simple $LONG/${b}/frc_pb/*gff $LONG/${b}/frc_pb/*_assemblyTable.csv
#    getreapr_simple_longread $LONG/${b}/reapr_pb/output_directory/ 

     #ONT - aln stats, sniffles, ALE, FRC, REAPR
#    getlongreadstats_simple ${LONG}/${b}/mreads/ont*simple.txt
#    getsniffles_simple ${LONG}/${b}/sniffles_ont
#     getale_simple_long $LONG/${b}/ale_ont/*ALE.txt
#     getfrc_simple $LONG/${b}/frc_ont/*gff $LONG/${b}/frc_ont/*_assemblyTable.csv
#    getreapr_simple_longread_lowcov $LONG/${b}/reapr_ont/output_directory/ 

     #BioNano
    getmaligner $b

     # Old Busco
#    getbusco_simple $SHORT/${b}/busco/*/short*

     # New Busco
     # Known Seq
     # Transcriptome
     # Dmel
     # Anopheles
     # RNA-seq
}

##TODO-continue to update as above is updated - jun19
function debugsimple {
    line=$1
    b=$2
    SIZE=`getsizestats_vizmat $line | wc `
    BUSCO=`getbusco_simple $SHORT/${b}/busco/*/short* | wc -l`
    BT2=`getbowtie2_simple $SHORT/${b}/mreads/*.err | wc -l`
    ALE=`getale_simple $SHORT/${b}/ale/*ALE.txt | wc -l`
    LAP=`getlap $SHORT/${b}/lap/*.lapscore | wc -l`
    REAPR=`getreapr_simple $SHORT/${b}/reapr/output_directory/ | wc -l`
    FRC=`getfrc_simple $SHORT/${b}/frc/*gff $SHORT/${b}/frc/*frc_assemblyTable.csv | wc -l`
    BNG=`getmaligner $b | wc -l`
    MAPONT=`getlongreadstats_simple ${LONG}/${b}/mreads/ont*simple.txt | wc -l`
    SNIFFONT=`getsniffles_simple ${LONG}/${b}/sniffles_ont | wc -l`
    MAPPB=`getlongreadstats_simple ${LONG}/${b}/mreads/pacbio*simple.txt | wc -l`
    SNIFFPB=`getsniffles_simple ${LONG}/${b}/sniffles_pb | wc -l`

    for var in SIZE BUSCO BT2 ALE LAP REAP FRC BNG SNIFFONT SNIFFPB; do
        echo -e $var"\t"${!var}
    done
    
}




function getnames_simple {
    echo $SIMPLENAMES
}

function getfactors_simple {
    echo $SIMPLEFACTORS
}

function main {
    LONGTABLE=tables
    if [ ! -d $LONGTABLE ]; then mkdir $LONGTABLE; fi
    if [ $DEBUG == "debugsimple" ]; then
        ##echo DEBUG
        while read line; do
            b=`basename $line .fasta`
            debugsimple $line $b > $LONGTABLE/$b.longtable.debugsimple
        done < $FOFN
    elif [ $DEBUG == "simple" ]; then
        ##echo SIMPLE
        while read line; do
            b=`basename $line .fasta`
            getsimple $line $b > $LONGTABLE/$b.longtable.simple
        done < $FOFN
    elif [ $DEBUG == "simplenames" ]; then
        ##echo SIMPLE NAMES
        getnames_simple
    elif [ $DEBUG == "simplefactors" ]; then
        ##echo SIMPLE NAMES
        getfactors_simple
    fi
}


### EXECUTE
main

#!/bin/bash

## Input Assemblies FOFN
ASMFOFN=input.fofn
##ASMFOFN=debug.fofn
CLEANALL=true

## GETTING ABS PATH OF ASMFOFN
ASMFOFN=`readlink -f $ASMFOFN`

RENAME=true


###################  SHORT READ  ###########################
# specify paths to lap read sample (LR1,LR2) and all reads (R1,R2)-- give dummy answers if will not be using (that will serve as place-holders)
R1=`readlink -f ../data/sim_ilmn_pe/ilmn.1.fastq`
R2=`readlink -f ../data/sim_ilmn_pe/ilmn.2.fastq`
LR1=$R1
LR2=$R2

## OPTIONS for what programs to use. 
## FILL IN   ==>"EvalThese"<==   BELOW WITH ONE OF THESE
ALL=eval.cfg
OnlyAle=eval.aleonly.cfg
OnlyBusco=eval.buscoOnly.cfg
OnlyLap=eval.laponly.cfg
OnlyReapr=eval.reapronly.cfg
OnlyReaprNoClean=eval.reapronly.noclean.cfg
OnlyReaprNoCleanAggressive=eval.reapronly.noclean.aggressive.cfg
OnlyPilon=pilon.eval.cfg
AleModule=alemodule.eval.cfg ## builds bt2, maps reads, runs ale


## FILL IN WITH CORRECT VARIABLE
EvalThese=$ALL

## May need to adjust the following
SHORTSCRIPTS=/gpfs_home/jurban/software/sciaratools/sciara-project-tools/slurmgear/shortreadeval/scripts/
SHORTAUTO=${SHORTSCRIPTS}/auto-shortreadeval.sh
SHORTEVAL=${SHORTSCRIPTS}/eval.ARGS.sh
SHORTCONFIG=${SHORTSCRIPTS}/configs/${EvalThese}


############### BIONANO MALIGNER SECTION #################
BIONANOCLEAN=false
if $CLEANALL; then BIONANOCLEAN=true; fi

REC_ENZ=BssSI
REC_SEQ=CACGAG

BIONANOBASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/opticalmap/malignerautomation
BIONANOSCRIPTS=${BIONANOBASE}/scripts/
BIONANOCONFIGS=${BIONANOBASE}/configs/
BIONANOFOFNS=${BIONANOBASE}/fofns/

BIONANOCONFIG=${BIONANOCONFIGS}/maligner-config-sciara.cfg
MAPSFOFN=`readlink -f ../data/sim_bng/maps.fofn`
BIONANORUN=${BIONANOSCRIPTS}/auto-malign.sh




############### LONG READ SECTION #################
## LONG READ LOCATIONS
ONT=`readlink -f ../data/sim_ont/ont.s.fastq`
PACBIO=`readlink -f ../data/sim_pb/pacbio.s.fastq`

## LONG2PE READ LOCATIONS
ONT1=`readlink -f ../data/sim_ont/long2pe/ont-1.fastq`
ONT2=`readlink -f ../data/sim_ont/long2pe/ont-2.fastq`
PACBIO1=`readlink -f ../data/sim_pb/long2pe/pacbio-1.fastq`
PACBIO2=`readlink -f ../data/sim_pb/long2pe/pacbio-2.fastq`

## RUN INFO LOCATIONS
LRBASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/longreadeval
LRSCRIPTS=${LRBASE}/scripts/
AUTOLR=${LRSCRIPTS}/auto-lrpipe.sh
LRCONFIGS=${LRBASE}/configs/
LR_DEFAULT_CFG=longread-config-sciara.cfg
LR_ALE_MODULE_CFG=ale-module-longread-config-sciara.cfg

LRCONFIG=${LRCONFIGS}/${LR_DEFAULT_CFG}


## OTHER OPTIONS
LRCLEAN=false
if $CLEANALL; then LRCLEAN=true; fi

############### TRANSCRIPT SECTION #################
TRANJOBPRE=transcript
TBLASTX=true
TRANSNJOBS=100
TRANSCLEAN=false
if $CLEANALL; then TRANSCLEAN=true; fi

TRANSBASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/transcripteval
TRANSSCRIPTS=${TRANSBASE}/scripts/
TRANSCONFIGS=${TRANSBASE}/configs/
TRANSFOFNS=${TRANSBASE}/fofns/

TRANSCONFIG=${TRANSCONFIGS}/trans-config-sciara.cfg ## does both blastn and tblastx
OTHERSPP_TRANSCONFIG=${TRANSCONFIGS}/other-spp-trans-config-sciara.cfg
TRANSFOFN=${TRANSFOFNS}/
TRANSRUN=${TRANSSCRIPTS}/auto-trans.sh

TRANS1=/gpfs/scratch/jurban/longreaddevo/data/ecolitranscriptome/Escherichia_coli_k_12.ASM80076v1.cdna.all.fa
TRANS2=/gpfs/scratch/jurban/longreaddevo/data/otherbacteria/salmonella/Salmonella_enterica.ASM78381v1.cdna.all.fa
TRANS3=/gpfs/scratch/jurban/longreaddevo/data/otherbacteria/pneumonia/Streptococcus_pneumoniae.6871_2_16.cdna.all.fa

TRANJOBPRE1=${TRANJOBPRE}_sciara_
TRANJOBPRE2=${TRANJOBPRE}_dmel_
TRANJOBPRE3=${TRANJOBPRE}_mosquito_

############### PEPTIDE SECTION #################
## Evaluate with peptides
PEPJOBPRE=peptide
PEPNJOBS=100
PEPCLEAN=false
if $CLEANALL; then PEPCLEAN=true; fi

PEPBASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/peptideval
PEPSCRIPTS=${PEPBASE}/scripts/
PEPCONFIGS=${PEPBASE}/configs/
PEPFOFNS=${PEPBASE}/fofns/

PEPCONFIG=${PEPCONFIGS}/peptide-config-sciara.cfg ## does both blastn and tblastx
PEPFOFN=${PEPFOFNS}/
PEPRUN=${PEPSCRIPTS}/auto-pep.sh

PEP2=/gpfs/scratch/jurban/longreaddevo/data/otherbacteria/salmonella/Salmonella_enterica.ASM78381v1.pep.all.fa
PEP3=/gpfs/scratch/jurban/longreaddevo/data/otherbacteria/pneumonia/Streptococcus_pneumoniae.6871_2_16.pep.all.fa

PEPJOBPRE2=${PEPJOBPRE}_dmel_
PEPJOBPRE3=${PEPJOBPRE}_mosquito_

############### KNOWN SEQUENCES SECTION #################
## Also evaluate Known Seqs
## USE TRANS variables (e.g. TRANSSCRIPTS etc) for everything other than these 4 things
KNOWNJOBPRE=knownseqs_
KNOWNTBLASTX=false
KNOWNNJOBS=1
KNOWNCLEAN=false
if $CLEANALL; then KNOWNCLEAN=true; fi

KNOWNCONFIG=${TRANSCONFIGS}/known-config-sciara.cfg 

KNOWNSEQS=/gpfs/scratch/jurban/longreaddevo/data/ecoliknownseqs/knownseqs.fa


############### RNASEQ SECTION #################
#$RNARUN $RNASCRIPTS $RNACONFIG $RNACLEAN $ASMFOFN $RNAFOFN

RNACLEAN=false
if $CLEANALL; then RNACLEAN=true; fi

RNABASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/rnaseqeval
RNASCRIPTS=${RNABASE}/scripts/
RNACONFIGS=${RNABASE}/configs/
RNAFOFNS=${RNABASE}/fofns/

RNACONFIG=${RNACONFIGS}/rnaseq-config-sciara.cfg
RNAFOFN=${RNAFOFNS}/reads.fofn
RNARUN=${RNASCRIPTS}/auto-rnaseqeval.sh

RNAFOFN=rnaseqreads.fofn
RNAFOFN=`readlink -f $RNAFOFN`


############### BUSCO V3 SECTION #################
BUSCOV3CLEAN=true
BUSCOV3BASE=/users/jurban/software/sciaratools/sciara-project-tools/slurmgear/buscov3
BUSCOV3SCRIPTS=${BUSCOV3BASE}/scripts/
BUSCOV3CONFIGS=${BUSCOV3BASE}/configs/
BUSCOV3FOFNS=${BUSCOV3BASE}/fofns/
BUSCOV3CONFIG=${BUSCOV3CONFIGS}/buscov3-config-sciara.cfg
BUSCOV3RUN=${BUSCOV3SCRIPTS}/auto-buscov3.sh





##############################################
##############################################
##############################################
################ EXECUTE #####################
if $RENAME; then echo renaming....;
 mkdir renamed_asms
 while read fasta; do
  b=`basename $fasta`
  fasta_name_changer.py -f $fasta -r contig -n > renamed_asms/${b}
 done < $ASMFOFN
 for f in renamed_asms/*; do
  readlink -f $f; done > renamed.fofn
 ASMFOFN=`readlink -f renamed.fofn`
else
 echo Skip renaming....
fi

echo shortread
mkdir shortread
cd shortread
bash $SHORTAUTO $ASMFOFN $LR1 $LR2 $R1 $R2 $EvalThese $SHORTSCRIPTS
cd ../

echo bionano
mkdir bionano
cd bionano
$BIONANORUN $BIONANOCLEAN $BIONANOCONFIG $ASMFOFN $MAPSFOFN $REC_ENZ $REC_SEQ $BIONANOSCRIPTS
cd ../

echo longread
mkdir longread
cd longread 
bash $AUTOLR $LRCLEAN $LRCONFIG $ASMFOFN $LRSCRIPTS $ONT $PACBIO $ONT1 $ONT2 $PACBIO1 $PACBIO2
cd ../

echo blast_analyses
mkdir blast_analyses
cd blast_analyses

echo transcriptome
mkdir transcriptome
cd transcriptome
$TRANSRUN $TRANSSCRIPTS $TRANSCONFIG $TRANSCLEAN $ASMFOFN $TRANS1 $TRANSNJOBS $TBLASTX $TRANJOBPRE1
cd ../

echo dmel
mkdir dmel
cd dmel
$TRANSRUN $TRANSSCRIPTS $OTHERSPP_TRANSCONFIG $TRANSCLEAN $ASMFOFN $TRANS2 $TRANSNJOBS $TBLASTX $TRANJOBPRE2
cd ../

echo anopheles
mkdir anopheles
cd anopheles
$TRANSRUN $TRANSSCRIPTS $OTHERSPP_TRANSCONFIG $TRANSCLEAN $ASMFOFN $TRANS2 $TRANSNJOBS $TBLASTX $TRANJOBPRE3
cd ../

echo dmel_peptides
mkdir dmel_peptides
cd dmel_peptides
$PEPRUN $PEPSCRIPTS $PEPCONFIG $PEPCLEAN $ASMFOFN $PEP2 $PEPNJOBS $PEPJOBPRE2
cd ../

echo anopheles_peptides
mkdir anopheles_peptides
cd anopheles_peptides
$PEPRUN $PEPSCRIPTS $PEPCONFIG $PEPCLEAN $ASMFOFN $PEP2 $PEPNJOBS $PEPJOBPRE3
cd ../

echo knownseqs
mkdir knownseqs
cd knownseqs
$TRANSRUN $TRANSSCRIPTS $KNOWNCONFIG $KNOWNCLEAN $ASMFOFN $KNOWNSEQS $KNOWNNJOBS $KNOWNTBLASTX $KNOWNJOBPRE
cd ../

#leave blast_analyses
cd ../

echo rnaseq
mkdir rnaseq
cd rnaseq
$RNARUN $RNASCRIPTS $RNACONFIG $RNACLEAN $ASMFOFN $RNAFOFN
cd ../

echo buscov3
mkdir buscov3
cd buscov3
$BUSCOV3RUN $BUSCOV3SCRIPTS $BUSCOV3CONFIG $BUSCOV3CLEAN $ASMFOFN 
cd ../

################ EXECUTE #####################
##############################################
##############################################
##############################################






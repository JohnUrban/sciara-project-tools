wget ftp://ftp.ensemblgenomes.org/pub/release-32/bacteria//fasta/bacteria_89_collection/salmonella_enterica/cdna/Salmonella_enterica.ASM78381v1.cdna.all.fa.gz
gunzip Salmonella_enterica.ASM78381v1.cdna.all.fa.gz

wget ftp://ftp.ensemblgenomes.org/pub/release-32/bacteria//fasta/bacteria_89_collection/salmonella_enterica/pep/Salmonella_enterica.ASM78381v1.pep.all.fa.gz
gunzip Salmonella_enterica.ASM78381v1.pep.all.fa.gz



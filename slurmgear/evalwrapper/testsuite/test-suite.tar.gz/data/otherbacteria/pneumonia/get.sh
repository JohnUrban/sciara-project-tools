wget ftp://ftp.ensemblgenomes.org/pub/release-32/bacteria//fasta/bacteria_102_collection/streptococcus_pneumoniae/cdna/Streptococcus_pneumoniae.6871_2_16.cdna.all.fa.gz
gunzip Streptococcus_pneumoniae.6871_2_16.cdna.all.fa.gz

wget ftp://ftp.ensemblgenomes.org/pub/release-32/bacteria//fasta/bacteria_102_collection/streptococcus_pneumoniae/pep/Streptococcus_pneumoniae.6871_2_16.pep.all.fa.gz
gunzip Streptococcus_pneumoniae.6871_2_16.pep.all.fa.gz

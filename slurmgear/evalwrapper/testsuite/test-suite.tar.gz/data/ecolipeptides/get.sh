

wget ftp://ftp.ensemblgenomes.org/pub/release-32/bacteria//fasta/bacteria_90_collection/escherichia_coli_k_12/pep/Escherichia_coli_k_12.ASM80076v1.pep.all.fa.gz
gunzip Escherichia_coli_k_12.ASM80076v1.pep.all.fa.gz

#!/bin/bash

FQ=../ont.s.fastq
NEW=ont
PRE=${NEW}-tmp

python ~/software/sciaratools/sciara-project-tools/longRead2PairedReads.py -f $FQ --fq --ofq -l 1500 -r 500 -s 2000 -o $PRE
python ~/software/sciaratools/sciara-project-tools/longRead2PairedReads.py -f $FQ --fq --ofq -l 1500 -r 500 -s 2000 -o $PRE.offset -S 500


cat ${PRE}-1.fastq ${PRE}.offset-1.fastq > ${NEW}-1.fastq
cat ${PRE}-2.fastq ${PRE}.offset-2.fastq > ${NEW}-2.fastq
cat ${PRE}.stats.txt ${PRE}.offset.stats.txt > ${NEW}.stats.txt
rm ${PRE}*



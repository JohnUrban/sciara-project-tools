#!/bin/bash

export PATH=~/software/svsim/SVsim/:$PATH

##IN=../ecoligenome/01-ecoli_k12_mg1655_NC_000913.3.fasta
IN=../snpdecoligenome/02-ecoli-snpd-genome.fasta
OUT=03-ecoli.mutated

if [ ! -f $IN.fai ]; then samtools faidx $IN; fi

SVsim -i sv.commands -r $IN -o $OUT -W
